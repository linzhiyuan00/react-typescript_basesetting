import React, { useState, useEffect, Fragment, useReducer } from 'react';
import {  } from '@components/common/com_component';
function App_Back(Route: any) {
    return function (props: any) {
        return (
            <div className="back" >
                <Route {...props} />
            </div>
        )
    }
}

export default App_Back