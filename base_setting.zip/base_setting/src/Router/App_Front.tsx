import React, { useState, useEffect, Fragment } from 'react';
import {  } from '@components/common/com_component';


function App_Front(Route: any) {
    return function (props: any) {
        // console.log(props)
        return (
            <div className="front">
                <Route {...props} />
            </div>
        )
    }
}

export default App_Front;
