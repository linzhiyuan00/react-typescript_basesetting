import React, { useState, useEffect, Fragment } from 'react';
import { HashRouter, BrowserRouter, Switch, Route, Redirect, NavLink } from 'react-router-dom';
import Store from '@reduxaction/store.js';
import { Spin } from 'antd';
import { createBrowserHistory } from 'history';
const history = createBrowserHistory();
// 页面按需加载
import loadable from 'react-loadable';


// 网站前台
import App_Front from './App_Front';
const App_Front_Route = App_Front(Route);
// 网站后台
import App_Back from './App_Back';
const App_Back_Route = App_Back(Route);

function loading() {
    return (
        <Spin size="large">
            <div className="loading_page"></div>
        </Spin >
    )
}

// 首页 不使用懒加载
import Index from '@pages/Index/Index';





// 登录
const Login = loadable({
    loader: () => import(/* webpackChunkName:'Login'*/'@pages/Login/Login'),
    loading: loading
})
// 注册
const Register = loadable({
    loader: () => import(/* webpackChunkName:'Register'*/'@pages/Register/Register'),
    loading: loading
})
// 忘记密码
const ForgotPassword = loadable({
    loader: () => import(/* webpackChunkName:'ForgotPassword'*/'@pages/ForgotPassword/ForgotPassword'),
    loading: loading
})



function AppRouter(props: any) {

    return (
        <BrowserRouter basename='/' >
            <Switch>
                <App_Front_Route exact path='/' component={Index} />
                <App_Front_Route exact path='/Index' component={Index} />
                <Route exact path='/Register' component={Register} />
                <App_Back_Route exact path='/Login' component={Login} />
                <Route exact path='/ForgotPassword' component={ForgotPassword} />
            </Switch>
        </BrowserRouter >
    );

}

export default AppRouter