function trim(string: String) {
    return string.replace(/(^[\s]+)|([\s]+$)/g, '');
}

function trimall(string: String) {
    return string.replace(/\s+/g, '');
}



export {
    trim,
    trimall,
}