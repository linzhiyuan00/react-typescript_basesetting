import { trim,trimall } from './comfunc';

export {
    trim,
    trimall
}