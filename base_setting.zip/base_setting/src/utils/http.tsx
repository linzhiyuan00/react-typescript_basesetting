import axios from 'axios';
import Qs from 'qs';
import { createBrowserHistory } from "history";
let is_in_development = process.env.NODE_ENV === 'development',
    arg = window.arg,
    base_url = is_in_development
        ? 'https://lalalal.com'
        : '',
    CancelToken = axios.CancelToken,
    source = CancelToken.source();

const options = {
    baseURL: base_url + '/web',
    params: {
        arg,
    },
    transformRequest: [function (data: any) {
        if (data && data.is_json_data) {
            delete data.is_json_data;

            return JSON.stringify(data);
        }
        return Qs.stringify(data);
    }],
    xsrfCookieName: 'XSRF-TOKEN',
    xsrfHeaderName: 'X-XSRF-TOKEN',
    headers: {
        // 'isback': 'yes'
        // 'Accept': 'json',
        // "X-Requested-With" : 'XMLHttpRequest',
        // 'Content-Type': 'application/json;charset=UTF-8'
    },
    withCredentials: true,
};
// window.http_head && (options.headers['X-CSRF-TOKEN'] = window.http_head);
window.$http = axios.create(options);
// 配置发送请求拦截器
window.$http.interceptors.request.use((config: any) => {
    /* config = {
        ...config,
        cancelToken: source.token,
        debounce_id:  Date.now(),
    }
    timer[is_in_development?config.baseURL + '/' + config.url:config.url] = config.debounce_id; */
    return config;
})
//返回拦截器
window.$http.interceptors.response.use((response: any) => {
    /* let {url,debounce_id} = response.config;
    if(debounce_id==timer[url]){
        return new Promise(() => {},() => {});
    }else{
        return response;
    } */
    return response;
})

//监听路由变化
const unlisten = createBrowserHistory().listen((location, action) => {
    source.cancel('路由跳转');
    source = CancelToken.source();
})