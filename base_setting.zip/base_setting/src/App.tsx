import React, { Component } from 'react';
import AppRouter from './Router/Router';
import { Provider } from 'react-redux';
import Store from './reduxstore/store';
import { ConfigProvider } from 'antd';
import '@utils/http';
import zhCN from 'antd/lib/locale/zh_CN';

class App extends Component {

  render() {
    return (
      <ConfigProvider locale={zhCN} >
        <Provider store={Store}>
          <div className="App">
            <AppRouter refreshpage={() => this.forceUpdate()}></AppRouter>
          </div>
        </Provider>
      </ConfigProvider>
    )
  }
}

export default App;
