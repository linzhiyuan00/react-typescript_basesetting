const initState = {
    Login: false,
    UserInfo: {}
};

function reducer(state = initState, action) {
    switch (action.type) {
        case 'SET_LOGIN':
            return {
                ...state,
                Login: action.value
            }
        case 'SET_USERINFO':
            return {
                ...state,
                UserInfo: action.value
            }
        default:
            return state;
    }
}

export {
    initState,
    reducer
}