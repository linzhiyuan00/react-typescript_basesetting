import { createStore, applyMiddleware, combineReducers, compose } from 'redux';
import thunk from 'redux-thunk';
import { reducer } from './allReducers';


const composeEnhancers = process.env.NODE_ENV === 'development'
    ? window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ || compose
    : compose;//redux DevTools ----google插件添加语句
const Store = createStore(reducer, /* preloadedState, */ composeEnhancers(
    applyMiddleware(thunk)
));
export default Store;