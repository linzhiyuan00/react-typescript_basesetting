import Svg_Icon from './Svg_Icon/Svg_Icon';
import Icon_Font from './Icon_Font/Icon_Font';

export {
    Svg_Icon,
    Icon_Font,
}