import React from 'react';
import Icon from '@ant-design/icons';

// 海客谈logo
import LOGOSVG from '@assets/img/LOGO.svg';
const LOGO = (props: any) => <Icon component={LOGOSVG} style={{ fontSize: 40}} {...props} />;





const Svg_Icon = (props: any) => {
    const { type } = props;

    if (type === "logo") {
        return <LOGO {...props} />;
    }
}

export default Svg_Icon; 
