import { createFromIconfontCN } from '@ant-design/icons';
import React, { Fragment } from "react";

const IconFonticon = createFromIconfontCN({
    scriptUrl: '',
});

// 对icon进行处理
function Icon_Font(props:any) {

    function rendericon(props:any) {
        if (props.type === '') {
            return (
                <Fragment></Fragment>
            )
        } else {
            return (
                <span className="icon_border">
                    <IconFonticon {...props} type={props.type} style={{ fontSize: props.size || 20 + 'px', color: `${props.color}` }} />
                </span>
            )
        }
    }

    return (
        <Fragment>
            {
                rendericon(props)
            }
        </Fragment>
    )
}

export default Icon_Font;