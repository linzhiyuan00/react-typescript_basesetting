import { Input, Button, message } from 'antd';
import React, { useState, useEffect, Fragment } from 'react';
import { Icon_Font, Svg_Icon } from '@components/common/com_component';
import './Index.less';
const { Search } = Input;
import ddd from '@assets/ddd.jpg';


function Index(props: any) {
   

    return (
        <Fragment>

        </Fragment>
    );
}

export default Index