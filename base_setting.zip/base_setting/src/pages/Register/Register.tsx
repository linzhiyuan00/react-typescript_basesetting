import React, { useState, useEffect, Fragment } from 'react';
import { Icon_Font, Svg_Icon, Header_Tip_back, Page_Header_back, Page_Bottom, FullTip_Page_back } from '@components/common/com_component';
import { trimall } from '@utils/utils';
import './Register.less';
import Store from '@reduxaction/store.js';
import { Button, Input, Checkbox, message } from 'antd';

function Register(props: any) {
   

    return (
        <Fragment>
        </Fragment>

    );
}

export default Register; 