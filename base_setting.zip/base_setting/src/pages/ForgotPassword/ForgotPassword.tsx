import React, { useState, useEffect, Fragment, useReducer } from 'react';
import { Icon_Font, Svg_Icon,} from '@components/common/com_component';
import './ForgotPassword.less';
import { trimall } from '@utils/utils';
import { Button, Input, Radio, message } from 'antd';
import { connect } from 'react-redux';

function ForgotPassword(props: any) {

   
    return (
        <Fragment>

        </Fragment>

    );
}

// const mapStateToProps = (state: any) => {
//     console.log(state)
//     return state;
// }

// const mapDispatchToProps = (dispatch: any) => ({
//   
// })

// export default connect(mapStateToProps, mapDispatchToProps)(ForgotPassword)
export default ForgotPassword