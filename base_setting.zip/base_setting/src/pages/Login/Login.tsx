import React, { useState, useEffect, Fragment } from 'react';
import { Icon_Font, Svg_Icon } from '@components/common/com_component';
import './Login.less';
import { trimall } from '@utils/utils';
import Store from '@reduxaction/store.js';
import { Button, Input, message, Radio } from 'antd';

function Login(props: any) {

   

    return (
        <Fragment>

        </Fragment>
    );
}

export default Login