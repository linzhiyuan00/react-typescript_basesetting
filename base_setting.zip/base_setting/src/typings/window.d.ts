declare interface Window {
  arg:String,
  user_info:any,
  $http:function
}