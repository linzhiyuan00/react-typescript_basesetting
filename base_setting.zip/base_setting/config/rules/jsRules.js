// js规则配置
const { pathjoin } = require('../utils');
const tsImportPlugin = require('ts-import-plugin');

module.exports = [
    {
        test: /\.ts(x?)$/,
        use: {
            // 处理ts转为js
            loader: 'awesome-typescript-loader',
            options: {
                transpileOnly: true,
                getCustomTransformers: () => ({
                    before: [
                        // 按需引入antd
                        tsImportPlugin({
                            libraryName: 'antd',
                            libraryDirectory: 'lib',
                            style: true
                        }),
                        tsImportPlugin({
                            libraryName: "@ant-design",
                            libraryDirectory: "icons",
                            camel2DashComponentName: false,  // default: true
                        })
                    ]
                })
            }
        }
    },
]