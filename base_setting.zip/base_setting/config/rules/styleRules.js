// 样式规则配置
const MiniCssExtractPlugin = require('mini-css-extract-plugin')
const { pathjoin } = require('../utils')

module.exports = [
    {
        test: /\.less$/,
        use: [
            // 'style-loader',
            {
                loader: MiniCssExtractPlugin.loader,
                options: {
                    publicPath: '../',
                }
            },
            'css-loader',
            {
                // 处理less
                loader: "less-loader",
                options: {
                    javascriptEnabled: true,
                    modifyVars: {
                        // 对antd手动配置全局颜色   base.less
                        'primary-color': '#0471E3', //主题色
                        'link-color': '#0471E3', // 链接色
                        'success-color': '#399E0E', // 成功色
                        'warning-color': '#FAAD14', // 警告色
                        'error-color': '#DA041B', // 错误色
                        'font-size-base': '14px', // 主字号
                        'heading-color': '#191919', // 标题色
                        'text-color': '#333333', // 主文本色
                        'text-color - secondary': '#999999', // 次文本色
                        'disabled-color': ' #CCCCCC', // 失效色
                        'border-radius-base': '4px', // 组件/浮层圆角
                        // 'border-color - base': '#d9d9d9', // 边框色
                        // 'box-shadow - base': '0 3px 6px - 4px rgba(0, 0, 0, 0.12), 0 6px 16px 0 background: rgba(0, 0, 0, 0.08); ',
                        // '0 9px 28px 8px rgba(0, 0, 0, 0.05)' // 浮层阴影
                    }
                }
            }
        ]
    },
]