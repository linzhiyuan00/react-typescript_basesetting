// 文件规则配置
const { pathjoin, pathdist } = require('../utils');

module.exports = [
    {
        test: /\.svg$/,
        include: pathjoin('src'),
        use: [
            {
                loader: '@svgr/webpack',
                options: {
                    esModule: false,
                    babel: true,
                    icon: true
                },
            }
        ],

    },
    {
        test: /\.(png|jpg|mp4)$/,
        include: pathjoin('src'),
        use: [
            {
                loader: 'url-loader',
                // 文件大小超过8k 或复用性高  单独打包不编码base64
                options: {
                    esModule: false,
                    limit: 8192,
                    name: 'assets/[name].[ext]'
                }
            }
        ],
    }
]
