const TerserPlugin = require('terser-webpack-plugin');
const CssMinimizerPlugin = require('css-minimizer-webpack-plugin');

module.exports = {

    minimizer: [
        new TerserPlugin({
            cache: true,
            parallel: true,
            sourceMap: false, // 如果在生产环境中使用 source-maps，必须设置为 true
            terserOptions: {
                // https://github.com/webpack-contrib/terser-webpack-plugin#terseroptions
            }
        }),
        new CssMinimizerPlugin(),   // css代码压缩
    ],
    // webpack生成维系各各代码块关系的代码
    runtimeChunk: {
        name: 'mainfest',
    },
    // 第三方代码打包 和 打包的文件名
    splitChunks: {
        cacheGroups: {
            default: false,
            commons: {
                test: /[\\/]node_modules[\\/]/,
                name: 'vendor',
                chunks: 'all'
            }
        }
    }

}