const plugins = require('./plugins');
const { pathjoin } = require('./utils');
const jsRules = require('./rules/jsRules');
const styleRules = require('./rules/styleRules');
const fileRules = require('./rules/fileRules');
const optimization = require('./optimization');
const TsconfigPathsPlugin = require('tsconfig-paths-webpack-plugin');


module.exports = {
    entry: {
        // 打包入口
        app: pathjoin('src/index.tsx'),
    },
    output: {
        // 打包后的路径
        path: pathjoin('dist'),
        filename: 'js/[name].js',
    },
    module: {
        rules: [...jsRules, ...styleRules, ...fileRules]
    },
    plugins: [...plugins],
    optimization: optimization,
    resolve: {
        // webpack需要解析的文件格式
        extensions: ['.ts', '.tsx', '.js', '.jsx', '.svg'],
        plugins: [
            new TsconfigPathsPlugin({
                // 配置文件引入tsconfig.js
                configFile: pathjoin('tsconfig.json')
            })
        ],
        alias: {
            '@assets': pathjoin('/assets'),
        }
    },
    devServer: {
        historyApiFallback: true,   // 默认匹配index.html
        hot: true,
        host: 'test.71baomu.com',
        open: true,
        port: '80'
    }
}