const HtmlWebpackPlugin = require('html-webpack-plugin');
const MiniCssExtractPlugin = require('mini-css-extract-plugin');
const { BundleAnalyzerPlugin } = require('webpack-bundle-analyzer');
const { pathjoin,pathdist } = require('./utils');

module.exports = [
    // 模板
    new HtmlWebpackPlugin({
        template: pathjoin('public/index.html')
    }),
    new MiniCssExtractPlugin({
        filename:pathdist('css/[name].css'),
        ignoreOrder: false, // 忽略有关顺序冲突的警告
    }),
    // new BundleAnalyzerPlugin({ analyzerPort: 8919 }) 

]