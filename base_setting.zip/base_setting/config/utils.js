const path = require('path');

// 路径指向根目录
const pathjoin = function (dir) {
    return path.join(__dirname, './../', dir);
}
// 指向dist文件
const pathdist = function (dir) {
    return path.join(dir);
}

module.exports = {
    pathjoin,
    pathdist
}
